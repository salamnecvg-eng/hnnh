# FreeDeck OS

Игровая ОС на ядре Linux (Debian 13 + XFCE + Steam Big Picture при запуске).
Это НЕ HTML — это проект сборки образа (live-build), из которого получается ISO.

## Что внутри
- Steam запускается сразу после включения (игровой режим)
- Рабочий стол XFCE с ярлыками: Steam, Google Chrome, Инструкция, Магазин приложений
- Установщик Calamares (установка на диск прямо с флешки)
- Flatpak + Flathub — скачивание программ из интернета

## Сборка
Linux:   sudo apt install live-build && sudo bash build.sh
Без Linux: загрузите всё в репозиторий GitHub — ISO соберётся автоматически
           (.github/workflows/build-iso.yml), готовый файл будет в Actions -> Artifacts.

## Структура
build.sh                                  — запуск сборки
.github/workflows/build-iso.yml           — облачная сборка на GitHub
config/package-lists/freedeck.list.chroot — список пакетов
config/hooks/live/0100-freedeck-setup...  — установка Steam и Chrome
config/includes.chroot_after_packages/    — файлы, копируемые в систему
