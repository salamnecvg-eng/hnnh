#!/bin/bash
# =====================================================================
#  FreeDeck OS — сборка ISO (Debian 13 "trixie" + ядро Linux)
#  Запускать от root в Debian/Ubuntu (или в Docker-контейнере debian:trixie):
#      apt-get install -y live-build
#      bash build.sh
#  Результат: файл freedeck-os-amd64.hybrid.iso в этой же папке.
# =====================================================================
set -e
cd "$(dirname "$0")"

# При загрузке через браузер GitHub теряет «исполняемый» бит — возвращаем.
chmod +x config/hooks/live/* 2>/dev/null || true
chmod +x config/includes.chroot_after_packages/usr/local/bin/* 2>/dev/null || true

lb clean || true

lb config \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi,syslinux" \
  --debian-installer none \
  --firmware-chroot true \
  --memtest none \
  --security true \
  --updates true \
  --iso-application "FreeDeck OS" \
  --iso-volume "FREEDECK" \
  --image-name "freedeck-os" \
  --bootappend-live "boot=live components quiet splash username=deck hostname=freedeck locales=ru_RU.UTF-8 keyboard-layouts=us,ru timezone=Europe/Moscow"

lb build

echo
echo "=============== ГОТОВО ==============="
ls -lh ./*.iso
